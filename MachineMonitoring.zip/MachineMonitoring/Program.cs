﻿using MachineMonitoring.Managers;
using MachineMonitoring.Models;
using MachineMonitoring.Services;
using System.ComponentModel;

public class Program
{

    private static void Main(string[] args)
    {

        MachineManager machineManager = new();
        ConsoleNotificationService notificationService = new();

        machineManager.AddMachines(001, "Trommelmaschine");
        machineManager.AddMachines(002, "Heiztrockner");

        machineManager.StartMachine(001);
        machineManager.StopMachine(002);

        machineManager.AddAlarmMachine(001, "Alarm - Hitze Obergrenze erreicht", AlarmSeverity.Warning);
        notificationService.Notify("Alarm");
    }

}