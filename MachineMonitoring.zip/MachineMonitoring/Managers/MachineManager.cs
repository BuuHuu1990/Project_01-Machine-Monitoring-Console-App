﻿using MachineMonitoring.Models;


namespace MachineMonitoring.Managers
{
    public class MachineManager
    {
        public List<Machine> Machines { get; set; } = new();

        public void AddMachines(int id, string name)
        {
            Machine machine = new Machine(id, name);
            Machines.Add(machine);
        }

        public void MachinesOutput()
        {
            foreach (var machine in Machines)
            {
                Console.WriteLine($"Machine ID: {machine.Id}, Machine name: {machine.Name}, Status: {machine.Status}, Alarm: {machine.Alarms}");
            }
        }

        public void StartMachine(int id)
        {
            foreach (var machine in Machines)
            {
                if(machine.Id  == id) 
                    machine.MachineStart();
            }
        }

        public void StopMachine(int id)
        {
            foreach (var machine in Machines)
            {
                if (machine.Id == id)
                    machine.MachineStop();
            }
        }

        public void AddAlarmMachine(int id, string message, AlarmSeverity severity)
        {
            foreach (var machine in Machines)
            {
                if (machine.Id == id)
                    machine.AddAlarm(message, severity);
            }
        }

        public void SearchMachine(int id)
        {
            var filteredList = Machines.Where(x => x.Id == id);
            Console.WriteLine($"Searched machine: {filteredList}");
        }

    }
}
