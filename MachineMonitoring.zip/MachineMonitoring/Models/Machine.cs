﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MachineMonitoring.Models
{
    public class Machine
    {
        public int Id { get; private set; }
        public string Name { get; private set; }
        public MachineStatus Status { get; private set; } = MachineStatus.Offline;
        public List<Alarm> Alarms { get; private set; } = new();

        public void MachineStart()
        {
            Status = MachineStatus.Running;
            Console.WriteLine($"ID: {Id}, Name: {Name}, Status: {Status}");
        }

        public void MachineStop() 
        { 
            Status = MachineStatus.Stopped;
            Console.WriteLine($"ID: {Id}, Name: {Name}, Status: {Status}");
        }
        public void MachineError(string message) 
        { 
            Status = MachineStatus.Error;
            Console.WriteLine($"ID: {Id}, Name: {Name}, Status: {Status}, Error: {message}");
        }

        public void AddAlarm(string message, AlarmSeverity severity) 
        {
            Alarm alarm = new(message, severity);
            Alarms.Add(alarm);
        }

        public Machine(int id, string name)
        {
            Id = id;
            Name = name;
        }

    }
}
